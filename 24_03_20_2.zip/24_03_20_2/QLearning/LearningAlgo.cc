/*
 * LearningAlgo.cc
 *
 *  Created on: Mar 4, 2020
 *      Author: master
 */


#include "LearningAlgo.h"
#include "stack/phy/layer/LtePhyUe.h"
#include <stdlib.h>
#include <time.h>
#include <random>
#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;



// Bundan önce action_ set edilmesi lazım
void LearningAlgo::actionDo(int state ){

   next_state_ = action_;
   done_ = observa(state);
   setMaxQ();
}

void LearningAlgo::deleteQ(){
    if(Q != NULL)
    {
        for (int i = 0; i < STATE_NUM; i++)
        {
            double* currentIntPtr = Q[i];
            free(currentIntPtr);
        }
       Q = NULL;
     }
}
void LearningAlgo::printQ_Table(){
    cout << "----------------Printing Q table-----------------" << endl;
    for(int x=0;x<STATE_NUM;x++)
    {
       cout << "[ " ;
       for(int y=0;y<ACTION_NUM;y++)
       {
           cout<<Q[x][y] << "  ";
       }
       cout<< " ] " << endl;
   }
}
bool LearningAlgo::observa(int state){
    bool result = false;

    if(state_ == state ){
        result = true;
    }

    return result;
}

int LearningAlgo::action_state_to_index(int a, int* b){
    int index;
    for(int i=0; i< ACTION_NUM ; i++){
        if(a == b[i])
            index = i ;
    }
    return index;
}


void LearningAlgo::actionGet(){
    int index = 0;
    int act = 0;

    double epsilone_ = FloatRandom2(0,1);// FloatRandom(0,1);


    if (epsilone_ < EPILSONE){
       index = static_cast<int> (FloatRandom2(1,STATE_NUM+1));
       act = action_list_[index-1];
   }else{
       getActionMax();
       act = max_action_;
   }
   action_ = act;
}

void LearningAlgo::initialize_QTable(){
     Q = (double **)malloc(STATE_NUM * sizeof(double*));

     for(int i = 0; i < STATE_NUM; i++){
         Q[i] = (double *)malloc(STATE_NUM * sizeof(double));
         for (int w = 0; w < ACTION_NUM; w++)
             Q[i][w] = 0;
     }
}

bool LearningAlgo::qNull(){

    bool res = false;

    if(Q != NULL)
        res = true;

    return res;
}



void LearningAlgo::setMaxQ(){
    int state = action_state_to_index(next_state_ , state_list_);

    double temp_max = 0;
    for (int i = 0; i < ACTION_NUM; ++i) {
        if (Q[state][i] > temp_max)
            temp_max = Q[state][i];
    }

    maxQ_ = temp_max;
}

void LearningAlgo::getTrainedAction(int state){
    int index;
    int index_state = action_state_to_index(state , state_list_);

    double max = 0;
    int act = 0;
    for(int i = 0; i < ACTION_NUM; i++){
        if(Q[index_state][i] > max ){
                max = Q[index_state][i];
                index = i;
        }
    }

    trained_action_ = action_list_[index];
}

void LearningAlgo::getActionMax(){

    int index;
    int index_state = action_state_to_index(state_ , state_list_);
    double max = Q[index_state][0];
    int act = 0;
    for(int i = 0; i < ACTION_NUM; i++){
        if(Q[index_state][i] > max ){
            max = Q[index_state][i];
            index = i;
         }
         if(Q[index_state][i] == 0)
             act = act + 1;
     }
     if(act == ACTION_NUM){
         index = static_cast<int>(FloatRandom2(1,STATE_NUM+1)) - 1;
     }
     max_action_ = action_list_[index];
}

void LearningAlgo::getMaxAct(int position){
    int index = 0;
    int index_state = position - 1;
    double max = Q[index_state][0];

    for(int i = 1; i < ACTION_NUM; i++){
        if(Q[index_state][i] > max ){
            max = Q[index_state][i];
            index = i;
         }
     }

    trained_action_ = action_list_[index];
}

void LearningAlgo::initializeRssiList(){
    list_rssi = new int[STATE_NUM];
}

void LearningAlgo::initiliaze_action_state_list(){
    action_list_ = new int[ACTION_NUM];
    state_list_ = new int[STATE_NUM];

    for(int i=0; i < ACTION_NUM; i++)
        action_list_[i] = i+1;

    for(int i=0; i < STATE_NUM; i++)
         state_list_[i] = i+1;
}

void LearningAlgo::print_State_Action(int* b){

    cout << "[ " ;
    for (int i = 0; i < STATE_NUM; i++) {
        cout << b[i] << "  " ;
    }
    cout <<" ] " << endl;
}

double LearningAlgo::FloatRandom(double a, double b){

    double random = ((double) rand()) / (double) RAND_MAX;
    double diff = b - a;
    double r = random * diff;

    return a + r;
}

double LearningAlgo::FloatRandom2(double a , double b){

    double value =  a + static_cast <double> (rand()) /( static_cast <double> (RAND_MAX/(b-a)));

  return value;
}
